# 水车

水车是一个5x5的发电机。 要使用水车，水必须在水车下面流动。这台发电机不会被天气或所处地点中断，唯一的要求是水。

![](betterwithmods:docs/imgs/waterwheel.png)
![](https://betterwithmods.github.io/Documentation/imgs/waterwheel.png)
