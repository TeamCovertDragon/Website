# 泛光灯

![泛光灯](block:betterwithmods:light)

泛光灯是一个简单的红石控制光源。这是在没有阳光的情况下种植[大麻](hemp.md)的唯一方法。
