# 熔魂钢压力板

![熔魂钢压力板](block:betterwithmods:steel_pressure_plate)