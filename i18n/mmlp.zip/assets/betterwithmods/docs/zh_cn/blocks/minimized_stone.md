# Minimized Stone


