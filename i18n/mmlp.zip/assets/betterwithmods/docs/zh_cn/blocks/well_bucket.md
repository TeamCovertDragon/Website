# 吊桶 

![吊桶](block:betterwithmods:well_bucket)

吊桶可以容纳8桶水。当紧邻水源放置时，它将缓慢填满缓冲区。吊桶可以连接到[Rope](../items/rope.md)，甚至可以通过[滑车](pulley.md)移动。
