# 螺杆泵

![螺杆泵](block:betterwithmods:screw_pump)

螺杆泵是一种机械装置，当从底部给予机械动力时，会将水从正面泵送到顶面，从而允许向上移动水源。
