# 机械螺杆助力轨道

![机械螺杆助力轨道](block:betterwithmods:booster)

当此导轨置于有动力的[变速箱](wooden_gearbox.md)顶部时，它将像加速轨道一样工作。
