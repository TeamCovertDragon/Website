# Filament

![Filament](item:betterwithmods:material@19)

A crafting component for the [Light Block](../blocks/light.md)