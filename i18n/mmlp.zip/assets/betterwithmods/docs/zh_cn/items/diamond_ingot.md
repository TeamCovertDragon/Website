# Diamond Ingot

![Diamond Ingot](item:betterwithmods:material@45)

