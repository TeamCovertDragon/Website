# Tanned Leather

![Tanned Leather](item:betterwithmods:material@6)

Leather is processed with a Tannin product, usually [Tree Bark](bark.md), in a [Cauldron](../blocks/cauldron.md) to help strength it and make it more useful.

Tanned Leather can be used to create durable Leather Straps which can be used to make mechanical Belts, [Animal Restraints](restraint.md) and more.


![Leather Belt](item:betterwithmods:material@9)
