# Blasting Oil

![Blasting Oil](item:betterwithmods:material@29)

Blasting Oil, created from Concentrated Hellfire and Tallow, is a highly volatile explosive material. It is so volatile that any quick disruption will cause it to explode. 