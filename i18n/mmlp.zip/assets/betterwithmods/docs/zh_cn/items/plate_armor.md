# Plate Armor

A highly durable suit of armor that can protect from almost any element. Created from [Soulforged Steel](soulforged_steel.md)

![Plate Helmet](item:betterwithmods:steel_helmet)
![Plate Chest](item:betterwithmods:steel_chest)
![Plate Leggings](item:betterwithmods:steel_pants)
![Plate Boots](item:betterwithmods:steel_boots)

 

