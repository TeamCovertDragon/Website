# Soulforged Steel

![Soulforged Steel](item:betterwithmods:material@14)

Soulforged Steel(SFS) is an alloy of Iron and [Carbon](carbon_dust.md) that is fused using the power of [Souls](../blocks/soul_urn.md).

SFS is a highly durable and shape-able alloy that has many potential uses, including:

 * [Plate Armor](plate_armor.md).
 
 * [Soulforged Steel Blocks](blocks:betterwithmods:steel_block) 