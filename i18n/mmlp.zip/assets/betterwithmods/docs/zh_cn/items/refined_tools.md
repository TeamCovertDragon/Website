# Refined Tools

Highly durable tools created from [Soulforged Steel](soulforged_steel.md) and [Hafts](haft.md) in an [Anvil](../blocks/anvil.md).

Refined Axe
![Refined Axe](item:betterwithmods:steel_axe)

Refined Pickaxe
![Refined Pickaxe](item:betterwithmods:steel_pickaxe)

Refined Shovel
![Refined Shovel](item:betterwithmods:steel_shovel)

Refined Sword
![Refined Sword](item:betterwithmods:steel_sword)

Refined Hoe
![Refined Hoe](item:betterwithmods:steel_hoe)

Refined Mattock - Combination Pickaxe and Shovel
![Refined Mattock](item:betterwithmods:steel_mattock)

Refined Battleaxe - Combination Sword and Axe.
![Refined Battleaxe](item:betterwithmods:steel_battleaxe)


